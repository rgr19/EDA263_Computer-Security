# README #

Labs for "EDA263 - Computer Security" course

-----------------------------------------------------------------

### Assignment 1 --- Identification and Authentication ###

In this laboratory assignment we will study identification and authentication and look closer at the requirements of a UNIX application that runs with higher privileges.

-----------------------------------------------------------------

### Assignment 2 --- Gnu Privacy Guard (GPG) ###

In this assignment we will learn how to setup and use gpg to sign, encrypt and decrypt files. You will also use gpg to sign and encrypt emails.

-----------------------------------------------------------------
